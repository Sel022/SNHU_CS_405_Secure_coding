#include <gtest/gtest.h>
#include <vector>
#include <stdexcept>
#include <memory>

// Mocked Collection class for demo purposes
class Collection {
public:
    Collection() : data_() {}

    bool empty() const { return data_.empty(); }
    size_t size() const { return data_.size(); }
    size_t capacity() const { return data_.capacity(); }

    void add_entries(size_t count) {
        for (size_t i = 0; i < count; ++i) {
            data_.push_back(static_cast<int>(i));
        }
    }

    void resize(size_t count) {
        data_.resize(count);
    }

    void clear() {
        data_.clear();
    }

    void erase_all() {
        data_.clear();
    }

    void reserve(size_t count) {
        data_.reserve(count);
    }

    int at(size_t index) const {
        return data_.at(index);
    }

private:
    std::vector<int> data_;
};

// Google Test
class CollectionTest : public ::testing::Test {
protected:
    void SetUp() override {
        collection = std::make_unique<Collection>();
    }

    std::unique_ptr<Collection> collection;
};

TEST_F(CollectionTest, CollectionIsEmptyInitially) {
    EXPECT_TRUE(collection->empty());
}

TEST_F(CollectionTest, CanAddSingleEntryToCollection) {
    collection->add_entries(1);
    EXPECT_EQ(collection->size(), 1);
}

TEST_F(CollectionTest, CanAddFiveEntriesToCollection) {
    collection->add_entries(5);
    EXPECT_EQ(collection->size(), 5);
}

TEST_F(CollectionTest, ResizingIncreasesCollection) {
    collection->resize(10);
    EXPECT_EQ(collection->size(), 10);
}

TEST_F(CollectionTest, ResizingDecreasesCollection) {
    collection->resize(10);
    collection->resize(5);
    EXPECT_EQ(collection->size(), 5);
}

TEST_F(CollectionTest, ResizingToZeroEmptiesCollection) {
    collection->resize(5);
    collection->resize(0);
    EXPECT_TRUE(collection->empty());
}

TEST_F(CollectionTest, ClearEmptiesCollection) {
    collection->add_entries(3);
    collection->clear();
    EXPECT_TRUE(collection->empty());
}

TEST_F(CollectionTest, EraseAllElementsEmptiesCollection) {
    collection->add_entries(3);
    collection->erase_all();
    EXPECT_TRUE(collection->empty());
}

TEST_F(CollectionTest, ReserveIncreasesCapacityButNotSize) {
    size_t old_capacity = collection->capacity();
    collection->reserve(old_capacity + 10);
    EXPECT_GE(collection->capacity(), old_capacity + 10);
    EXPECT_EQ(collection->size(), 0);
}

TEST_F(CollectionTest, AtThrowsOutOfRangeForInvalidIndex) {
    EXPECT_THROW(collection->at(0), std::out_of_range);
}

TEST_F(CollectionTest, FirstElementIsValidAfterAddingEntries) {
    collection->add_entries(3);
    EXPECT_EQ(collection->at(0), 0);
}

TEST_F(CollectionTest, AddEntriesWithZeroCountDoesNothing) {
    collection->add_entries(0);
    EXPECT_EQ(collection->size(), 0);
}
